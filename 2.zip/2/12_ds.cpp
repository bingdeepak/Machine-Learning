#include<bits/stdc++.h>
using namespace std;

int pow(int x,int y,int mod)
{
	int res = 1;
	while(y)
	{
		if(y & 1)
			res = (res*x)%mod;
		x = (x*x)%mod;
		y/=2;
	}
	return res;
}

int main()
{
	int p,m;
	cout<<"Enter large prime number p: ";
	cin>>p;
	cout<<"Enter message m: ";
	cin>>m;
	int q;
	cout<<"Enter q such that it is prime factor of (p-1): ";
	cin>>q;
	int d = rand()%(p-2) + 1;
	int g = pow(d, (p-1)/q, p);
	int x = rand()%q;
	int y = pow(q,x,p);
	cout<<"Alice is generating random number k between 1 and q..."<<endl;
	int k = rand()%(q-1) + 1;
	cout<<"Alice is generating signature..."<<endl;
	int r = pow(g,k,p)%q;
	int kin = pow(k,q-2,q);
	int S = (kin*(m+x*r))%q;
	cout<<"Alice is sending m,r,S to Bob..."<<endl;
	cout<<endl;
	cout<<"Bob is calculating w,u1,u2 and v..."<<endl;
	int w = pow(S,q-2,q);
	int u1 = (m*w)%q;
	int u2 = (w*r)%q;
	int v = (pow(q,u1,p)*pow(y,u2,p))%q;

	if(v==r)
	cout<<"Signature is Valid"<<endl;
	else
	cout<<"Signature is Invalid"<<endl;

}


