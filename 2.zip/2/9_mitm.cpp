#include<bits/stdc++.h> 
using namespace std; 
 
int pow(int x,int y,int mod) 
{ 
 	int res = 1; 
 	while(y) 
 	{ 
  if(y & 1)    res = (res*x)%mod; 
 	 	x = (x*x)%mod; 
 	 	y/=2; 
 	} 
 	return res; 
} 
 
int main() 
{ 
 	int g,p; 
 	cout<<"Enter integer g and prime number p shared with A,B and Adversary such that g<p and g is primitive root of p"<<endl;	   	
	 cin>>g; 
 	cin>>p; 
 
 	int a,b,c; 
 	cout<<"Enter Private Key of A: ";  	
	 cin>>a; 
 	cout<<"Enter Private Key of B: "; 
 	cin>>b; 
 	cout<<"Enter Private Key of Adversary: "; 
 	cin>>c; 
 
 	cout<<"A is calculating it's Public Key"<<endl; 
 	int A = pow(g,a,p); 
 	cout<<"Public Key of A: "<<A<<endl; 
 
 	cout<<"B is calculating it's Public Key"<<endl; 
 	int B = pow(g,b,p); 
 	cout<<"Public Key of B: "<<B<<endl; 
 
 	cout<<"Adversary is calculating it's Public Key"<<endl;  	
	 int C = pow(g,c,p); 
 	cout<<"Public Key of Adversary: "<<C<<endl; 
 
 	cout<<"A is sending it's public key to B"<<endl;  	
	 cout<<"B is sending it's public key to A"<<endl; 
 
 	cout<<"Adversary Intercepted"<<endl; 
 
 	cout<<"A has received public key of Adversary instead of public key of B"<<endl;  	
	 cout<<"B has received public key of Adversary instead of public key of A"<<endl; 
 
 	cout<<"A is calculating it's secret key"<<endl;  	
	 A = pow(C,a,p); 
 	cout<<"Secret Key of A: "<<A<<endl; 
 	cout<<"B is calculating it's secret key"<<endl;  	B = pow(C,b,p); 
 	cout<<"Secret key of B: "<<B<<endl; 
} 


