#include<bits/stdc++.h>
using namespace std;
string decryptionMessage(string CTxt,int a,int b)
{
    string Msg = "";
    int a_inv = 0;
    int flag = 0;
    for (int i = 0; i < 26; i++)
    {
        flag = (a * i) % 26;
        if (flag == 1)
        {
            a_inv = i;
        }
    }
    for (int i = 0; i < CTxt.length(); i++)
    {
        Msg = Msg + (char) (((a_inv * ((CTxt[i] - b)) % 26)) + 65);
    }
    return Msg;
}
int main(int argc,char **argv)
{
	string message="ISMVKHOB";
	cout<<"original message:"<<message<<endl;
	int k1,k2,i,j;
	int a[12]={1,3,5,7,9,11,15,17,19,21,23,25};
	for(int i=0;i<12;i++)
	{
		cout<<"a="<<a[i]<<endl;
		for(j=0;j<26;j++)
		{
			cout<<decryptionMessage(message,a[i],j)<<" ";
		}
		cout<<endl<<endl;
		}
		//cin>>k1;
		return 0;
	}	


