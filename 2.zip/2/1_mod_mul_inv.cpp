#include<iostream>

using namespace std;

int ExtEuc(int a,int b,int *x, int *y)
{
int x1,y1;
if(a==0)
{
*x=0;
*y=1;
return b;
}
int gcd = ExtEuc(b%a,a,&x1,&y1);

*x= y1-(b/a)*x1;
*y= x1;

return gcd;
}


int main()
{
int a,b,x,y;
cin>>a>>b;
int g= ExtEuc(a,b,&x,&y);
if(g!=1)
{
cout<<"Inverse doesn't exist";
return 0;
}
else
cout<<(x%b+b)%b;

return 0;
}

