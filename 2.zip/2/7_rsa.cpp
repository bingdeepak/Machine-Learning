#include<iostream> 
using namespace std;
 int phi(int p,int q) 
{ 
 	return (p-1)*(q-1); 
} 
void mulin(int a,int b,int& d,int& x,int& y) 
{ 
 	if(b == 0) 
 	{ 
 	 	d = a;x = 1;y = 0;
	    return;  
 	} 
 	int _d,_x,_y;
	mulin(b,a%b,_d,_x,_y);
	d = _d;
	x = _y; 
 	y = _x-(a/b)*_y; 
} 
 
int expo(int base,int exp,int mod) { 
 	int ans = 1; 
 	while(exp) 
 	{ 
 	 	if(exp&1) 
 	 	{ 
 	 	 	ans = (ans*base)%mod; 
 	 	} 
 	 	base = (base*base)%mod; 
 	 	exp = exp/2; 
 	} 
 	return ans; 
} 
 
int main() 
{ 
 	int p,q,n,i,ln,j,k,e,d; 
 	cout<<"Enter two large prime numbers "; 
 	cin>>p>>q;  	n = p*q; 
 	ln = phi(p,q); 
 	cout<<"Enter a number in the range 1 to phi(n) "; 
 	cin>>e; 
 	cout<<"Public key = ("<<n<<","<<e<<")\n"; 
 	cout<<"Private key of Bob = ("<<n<<","<<d<<")\n";  	int in,y;  	mulin(e,ln,k,d,y);  	d = (d+ln)%ln;  	int pt,ct; 
 	cout<<"Enter plaintext ";  	cin>>pt; 
 	ct = expo(pt,e,n); 
 	cout<<"Plaintext is being encrypted by Alice...\n"; 
 	cout<<"Cipher text = "<<ct<<"\n";  	pt = expo(ct,d,n); 
 	cout<<"Bob receives the ciphertext...\n";  	cout<<"Ciphertext is being decrypted by Bob...\n"; 
 	cout<<"Plaintext = "<<pt<<"\n"; 
} 


