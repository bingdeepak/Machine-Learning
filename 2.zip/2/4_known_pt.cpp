#include<bits/stdc++.h>
using namespace std;
int mulin(int a,int z)
{
	int a_inv = 0;
    int flag = 0;
    for (int i = 0; i < z; i++)
    {
        flag = (a * i) % z;
        if (flag == 1)
        {
            a_inv = i;
            return a_inv;
        }
    }
}
int main()
{
	string pt;
	cout<<"enter the plaintext: ";
	cin>>pt;
	string s;
	cout<<"enter the ciphertext: ";
	cin>>s;
	int n=s.length();
	int c[n],p[n];
	for(int i=0;pt[i];i++)
	p[i]=pt[i]-'A';
	for(int i=0;s[i];i++)
	c[i]=s[i]-'A';
	int d[n];
	int m[]={1,3,5,7,9,11,13,15,17,19,21,23,25};
	for(int i=0;i<12;i++)
	for(int j=0;j<26;j++)
	{
		int m1=mulin(m[i],26);
		for(int l=0;l<n;l++)
		d[l]=((((c[l]-j+26))%26)*m1)%26;
		int k;
		for(k=0;k<n;k++)
		if(d[k]!=p[k])
		break;
		if(k==n)
		{
		cout<<"a="<<m[i]<<"b="<<j<<endl;
		return 0;
	}
	}
	}

